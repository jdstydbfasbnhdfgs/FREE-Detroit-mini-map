shared_script "@ReaperV4/imports/bypass.lua"
shared_script "@ReaperV4/imports/bypass_s.lua"
shared_script "@ReaperV4/imports/bypass_c.lua"
lua54 "yes" -- needed for Reaper

fx_version 'cerulean'
game 'gta5'

author 'Itscalledzen'
description 'Custom Postal Map by 762 development'
discord 'https://discord.gg/762development'

this_is_a_map 'yes'

client_script "client.lua"
